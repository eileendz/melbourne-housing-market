library(tfruns)

runs <- tuning_run("house.R", flags = list(
  dense_unit1 = c(512, 256, 128, 64), 
  dense_unit2 = c(256, 128, 64, 32), 
  dropout = c(0.2, 0.3), 
  learning_rate = c(1e4, 1e5), 
  epoch = c(30, 50, 100), # could optimise with better grid value
  batch_size = c(16, 32,64) # c(16, 32, 64)
))

runs <- tuning_run("house.R", flags = list(
  dense_unit1 = c(128), 
  dense_unit2 = c(64), 
  dropout = c(0.2),
  learning_rate = c(1e4), 
  epoch = c(30), # could optimise with better grid value
  batch_size = c(32) # c(16, 32, 64)
))




run_result <- ls_runs() %>% unnest(metrics) %>% 
  dplyr::arrange(-metric_acc) %>% 
  select(metric_loss, metric_acc, flag_dropout, 
         flag_epoch, flag_batch_size, run_dir)

view_run(run_result$run_dir[1])
4*4*2*2*3*(15*(30+50+100)*3)