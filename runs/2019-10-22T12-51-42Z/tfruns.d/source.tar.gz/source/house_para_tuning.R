library(tfruns)

runs <- tuning_run("house.R", flags = list(
  dense_unit1 = c(256, 128), #c(512, 256, 128, 64)
  dense_unit2 = c(128, 64),
  dropout = c(0.1, 0.2), # dropout rate of 0.2 seems to be better than 0.4
  batch_size = c(128,256, 512), #,
  activation = c("relu","LeakyReLU" , "tanh") # LeakyReLU, , "tanh"
))

# may want to try if three layer is good but doubt about that

run_result <- ls_runs(latest_n = 108) %>% unnest(metrics) %>% 
  dplyr::arrange(metric_val_loss) %>% 
  select(metric_loss, metric_acc, metric_val_loss, metric_val_acc, flag_dropout, 
         flag_batch_size, flag_activation, run_dir)

view_run(run_result$run_dir[2]) # runs/2019-10-15T15-43-59Z

# more work could be done if we have a better computer
# increase patience to 20 so we can try learning rate at 1e-4 or 1e-5
# play around with different activation function: tanh or leaky relu - this would affect dropout tbh
